"use client";

import type { ReactNode } from "react";
import type { LucideIcon } from "lucide-react";
import { Cpu, Database, Gauge, Globe2, Layers, ScanSearch } from "lucide-react";
import { CATALOG_COUNTS } from "./catalog.data";
import { useReveal } from "../../lib/hooks";

type CapProps = {
  span: "lead" | "wide" | "third" | "full";
  icon: LucideIcon;
  title: string;
  body: string;
  viz?: ReactNode;
};

function Cap({ span, icon: Icon, title, body, viz }: CapProps) {
  const [revealRef, revealIn] = useReveal<HTMLElement>({ threshold: 0.3 });
  return (
    <article className={`nrc-cap nrc-cap--${span} ${revealIn ? "is-in" : ""}`} ref={revealRef}>
      <span className="nrc-cap-icon" aria-hidden="true">
        <Icon size={16} strokeWidth={1.9} />
      </span>
      <h3>{title}</h3>
      <p>{body}</p>
      {viz ? <div className="nrc-cap-viz">{viz}</div> : null}
    </article>
  );
}

const RETRIEVAL_BARS = [38, 62, 44, 88, 55, 71, 34, 96, 48, 66, 40, 79];

const CLIMATE_CHIPS = [
  { label: "Heat", on: true },
  { label: "UV", on: true },
  { label: "Chloride", on: true },
  { label: "Coastal", on: true },
  { label: "Hydrostatic", on: false },
  { label: "Traffic", on: false },
  { label: "Wet area", on: false },
];

export default function Features() {
  const [headRef, headIn] = useReveal<HTMLDivElement>();

  return (
    <section className="nrc-section" id="solutions">
      <div className="nrc-wrap">
        <div className={`nrc-rv ${headIn ? "is-in" : ""}`} ref={headRef}>
          <h2 className="nrc-h2">Built around how these products are actually chosen.</h2>
        </div>

        <div className="nrc-caps">
          <Cap
            span="lead"
            icon={Cpu}
            title="AI-powered recommendations"
            body="Describe the project as it exists on site. Get a decision, not a longlist."
            viz={
              <div className="nrc-meter">
                {[
                  { label: "Application", width: "92%", delay: 0 },
                  { label: "Substrate", width: "78%", delay: 120 },
                  { label: "Exposure", width: "85%", delay: 240 },
                ].map((row) => (
                  <div className="nrc-meter-row" key={row.label}>
                    <span>{row.label}</span>
                    <span className="nrc-meter-track">
                      <span
                        className="nrc-meter-fill"
                        style={
                          {
                            "--w": row.width,
                            "--d": `${row.delay}ms`,
                          } as React.CSSProperties
                        }
                      />
                    </span>
                  </div>
                ))}
              </div>
            }
          />

          <Cap
            span="wide"
            icon={Database}
            title="Retrieval-grounded knowledge"
            body="Answers are built from retrieved datasheets and product profiles — not from what the model remembers."
            viz={
              <div className="nrc-bars" aria-hidden="true">
                {RETRIEVAL_BARS.map((height, index) => (
                  <i
                    key={index}
                    style={
                      {
                        "--h": `${height}%`,
                        "--d": `${index * 45}ms`,
                        height: `${height}%`,
                      } as React.CSSProperties
                    }
                  />
                ))}
              </div>
            }
          />

          <Cap
            span="third"
            icon={ScanSearch}
            title="Semantic product search"
            body="Matches on what a product does, not on the words the query happened to use."
          />

          <Cap
            span="third"
            icon={Globe2}
            title="UAE construction focus"
            body="Selection logic built around the conditions that decide specifications in the Gulf."
            viz={
              <div className="nrc-chips">
                {CLIMATE_CHIPS.map((chip) => (
                  <span className={`nrc-chip${chip.on ? " nrc-chip--on" : ""}`} key={chip.label}>
                    {chip.label}
                  </span>
                ))}
              </div>
            }
          />

          <Cap
            span="third"
            icon={Gauge}
            title="Faster decisions"
            body="One query instead of an afternoon in catalogs — and a technical PDF at the end of it."
          />

          <Cap
            span="full"
            icon={Layers}
            title="Scalable intelligence"
            body={`${CATALOG_COUNTS.profiles.toLocaleString("en-US")} product profiles and ${CATALOG_COUNTS.marketProducts} market listings today. It grows as new catalogs and datasheets are ingested.`}
          />
        </div>
      </div>
    </section>
  );
}

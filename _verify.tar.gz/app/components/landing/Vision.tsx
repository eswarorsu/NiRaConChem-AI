"use client";

import { useReveal } from "../../lib/hooks";

const AHEAD = [
  { title: "Product discovery", body: "Systems that fit the condition, not the keyword." },
  { title: "Technical comparison", body: "Candidates side by side on what decides the spec." },
  { title: "Specification assistance", body: "A decision, in the wording a spec needs." },
  { title: "Project decision support", body: "Conditions carried across a whole project." },
  { title: "Knowledge management", body: "New catalogs and datasheets, ingested." },
];

export default function Vision() {
  const [headRef, headIn] = useReveal<HTMLDivElement>();
  const [gridRef, gridIn] = useReveal<HTMLDivElement>();

  return (
    <section className="nrc-section nrc-vision" id="vision">
      <div className="nrc-wrap">
        <div className={`nrc-rv ${headIn ? "is-in" : ""}`} ref={headRef}>
          <h2>Building the intelligence layer for construction chemistry.</h2>
          <p className="nrc-lede">
            Catalog, datasheet and site condition have always been three separate things.
            This is the layer that reads all three — starting with the UAE.
          </p>
        </div>

        <div className={`nrc-vision-grid nrc-rv ${gridIn ? "is-in" : ""}`} ref={gridRef}>
          {AHEAD.map((item) => (
            <article className="nrc-vision-item" key={item.title}>
              <strong>{item.title}</strong>
              <p>{item.body}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

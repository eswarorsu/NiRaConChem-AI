"use client";

import { CATALOG_COUNTS } from "./catalog.data";
import { useReveal } from "../../lib/hooks";

const CELLS = [
  {
    value: CATALOG_COUNTS.profiles.toLocaleString("en-US"),
    tail: "",
    title: "Product profiles",
    body: "One condition can match dozens of valid systems.",
  },
  {
    value: String(CATALOG_COUNTS.marketCategories),
    tail: "",
    title: "Categories",
    body: "Each with its own selection logic.",
  },
  {
    value: "6",
    tail: "+",
    title: "Variables per decision",
    body: "Substrate, exposure, movement, traffic, temperature, pressure.",
  },
  {
    value: CATALOG_COUNTS.marketProducts.toLocaleString("en-US"),
    tail: "",
    title: "Market listings",
    body: "Local options to check availability against.",
  },
];

export default function ProblemSection() {
  const [headRef, headIn] = useReveal<HTMLDivElement>();
  const [gridRef, gridIn] = useReveal<HTMLDivElement>();
  const [transitionRef, transitionIn] = useReveal<HTMLDivElement>();

  return (
    <section className="nrc-section" id="problem">
      <div className="nrc-wrap">
        <div className={`nrc-problem-head nrc-rv ${headIn ? "is-in" : ""}`} ref={headRef}>
          <div>
            <h2 className="nrc-h2">
              Choosing the right construction chemical shouldn&rsquo;t be guesswork.
            </h2>
          </div>
          <p className="nrc-lede">
            The information exists. It is just spread across catalogs, datasheets and site
            conditions that nobody has time to reconcile.
          </p>
        </div>

        <div className={`nrc-complexity nrc-rv ${gridIn ? "is-in" : ""}`} ref={gridRef}>
          {CELLS.map((cell) => (
            <article className="nrc-complexity-cell" key={cell.title}>
              <p className="nrc-complexity-n">
                {cell.value}
                {cell.tail ? <span>{cell.tail}</span> : null}
              </p>
              <h3 className="nrc-complexity-t">{cell.title}</h3>
              <p className="nrc-complexity-d">{cell.body}</p>
            </article>
          ))}
        </div>

        <div className={`nrc-transition ${transitionIn ? "is-in" : ""}`} ref={transitionRef}>
          <span className="nrc-transition-step">Complexity</span>
          <span className="nrc-transition-arrow" aria-hidden="true" />
          <span className="nrc-transition-step">Technical intelligence</span>
          <span className="nrc-transition-arrow" aria-hidden="true" />
          <span className="nrc-transition-step">NiRaConChem AI</span>
        </div>
      </div>
    </section>
  );
}

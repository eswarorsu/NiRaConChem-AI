"use client";

import Image from "next/image";
import { Download } from "lucide-react";
import { scrollToId } from "./nav";

type FooterProps = {
  onTryAi: () => void;
  canInstall: boolean;
  onInstall: () => void;
};

/**
 * Deliberately minimal. There is no contact route, no marketing site and no
 * verified social account in this project, so none is linked — a footer full of
 * dead links is the fastest way to make a product look unfinished.
 */
export default function Footer({ onTryAi, canInstall, onInstall }: FooterProps) {
  const year = new Date().getFullYear();

  return (
    <footer className="nrc-footer">
      <div className="nrc-wrap">
        <div className="nrc-footer-top">
          <div>
            <span className="nrc-brand">
              <span className="nrc-brand-mark" aria-hidden="true">
                <Image src="/icons/brand-mark.png" alt="" width={22} height={22} />
              </span>
              NiRaConChem AI
            </span>
            <p className="nrc-footer-tag">AI-powered construction chemical intelligence.</p>
          </div>

          <nav className="nrc-footer-nav" aria-label="Footer">
            <button onClick={() => scrollToId("top")} type="button">
              Home
            </button>
            <button onClick={onTryAi} type="button">
              AI Recommendations
            </button>
            <button onClick={() => scrollToId("technology")} type="button">
              Technology
            </button>
            <button onClick={() => scrollToId("vision")} type="button">
              About
            </button>
            {canInstall ? (
              <button onClick={onInstall} type="button">
                <Download size={13} strokeWidth={2.2} aria-hidden="true" /> Install app
              </button>
            ) : null}
          </nav>
        </div>

        <div className="nrc-footer-bottom">
          <span>© {year} NiRaConChem AI</span>
          <span>Construction chemical intelligence · United Arab Emirates</span>
        </div>
      </div>
    </footer>
  );
}

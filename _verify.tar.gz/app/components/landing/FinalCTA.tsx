"use client";

import { ArrowRight } from "lucide-react";
import { useReveal } from "../../lib/hooks";
import { scrollToId } from "./nav";

/* A quiet molecular lattice behind the closing statement: pure SVG, no runtime
   cost beyond a single CSS transform, and it echoes the hero without repeating it. */
function LatticeBackdrop() {
  const nodes = Array.from({ length: 26 }, (_, index) => {
    const angle = (index / 26) * Math.PI * 2;
    const radius = 190 + (index % 5) * 46;
    return {
      x: 600 + Math.cos(angle) * radius,
      y: 260 + Math.sin(angle) * radius * 0.62,
    };
  });

  return (
    <svg className="nrc-final-bg" viewBox="0 0 1200 520" aria-hidden="true" preserveAspectRatio="xMidYMid slice">
      {nodes.map((node, index) => {
        const next = nodes[(index + 3) % nodes.length];
        return (
          <line
            key={`l-${index}`}
            x1={node.x}
            y1={node.y}
            x2={next.x}
            y2={next.y}
            stroke="rgba(107,79,42,0.22)"
            strokeWidth="1"
          />
        );
      })}
      {nodes.map((node, index) => (
        <circle
          key={`c-${index}`}
          cx={node.x}
          cy={node.y}
          r={index % 4 === 0 ? 3 : 1.8}
          fill={index % 4 === 0 ? "rgba(107,79,42,0.65)" : "rgba(20,17,13,0.22)"}
        />
      ))}
    </svg>
  );
}

export default function FinalCTA({ onTryAi }: { onTryAi: () => void }) {
  const [revealRef, revealIn] = useReveal<HTMLDivElement>();

  return (
    <section className="nrc-section nrc-final" id="start">
      <LatticeBackdrop />
      <div className={`nrc-wrap nrc-final-inner nrc-rv ${revealIn ? "is-in" : ""}`} ref={revealRef}>
        <h2>Ready to make construction chemistry intelligent?</h2>
        <p>Explore construction chemicals through AI-powered technical intelligence.</p>
        <div className="nrc-final-actions">
          <button className="nrc-btn nrc-btn--primary" onClick={onTryAi} type="button">
            Try NiRaConChem AI
            <ArrowRight size={16} strokeWidth={2.2} aria-hidden="true" />
          </button>
          <button
            className="nrc-btn nrc-btn--ghost"
            onClick={() => scrollToId("technology")}
            type="button"
          >
            Explore the Technology
            <ArrowRight size={16} strokeWidth={2.2} aria-hidden="true" />
          </button>
        </div>
      </div>
    </section>
  );
}

"use client";

import { useReveal } from "../../lib/hooks";
import { CATALOG_COUNTS } from "./catalog.data";

/* Only what the repository actually runs. The platform uses a LangGraph agent
   over a local product-profile index and datasheet RAG chunks with a Groq-hosted
   model; there is no separate vector database service, so none is claimed. */
const LAYERS = [
  {
    n: "L1",
    name: "Frontend",
    desc: "Chat, market results, uploads and report download. Installable as a PWA.",
    tech: ["Next.js", "React", "TypeScript"],
  },
  {
    n: "L2",
    name: "API",
    desc: "Typed endpoints for chat, file analysis, ingestion and reports.",
    tech: ["FastAPI", "Uvicorn", "Pydantic"],
  },
  {
    n: "L3",
    name: "AI agent",
    desc: "Routes each request by intent.",
    tech: ["LangGraph"],
  },
  {
    n: "L4",
    name: "Retrieval",
    desc: "Datasheets parsed and chunked, then searched per query.",
    tech: ["RAG", "Document parsing"],
  },
  {
    n: "L5",
    name: "Knowledge index",
    desc: `${CATALOG_COUNTS.profiles.toLocaleString("en-US")} product profiles with their source documents.`,
    tech: ["Product profiles", "Semantic scoring"],
  },
  {
    n: "L6",
    name: "Language model",
    desc: "Writes the recommendation over retrieved context only.",
    tech: ["Groq"],
  },
  {
    n: "L7",
    name: "Report",
    desc: "Renders the technical PDF for the project record.",
    tech: ["ReportLab"],
  },
];

function Layer({ layer, index }: { layer: (typeof LAYERS)[number]; index: number }) {
  const [revealRef, revealIn] = useReveal<HTMLDivElement>({ threshold: 0.5, rootMargin: "0px 0px -12% 0px" });
  return (
    <div className={`nrc-layer ${revealIn ? "is-in" : ""}`} ref={revealRef}>
      <span className="nrc-layer-n">{layer.n}</span>
      <span className="nrc-layer-name">{layer.name}</span>
      <span className="nrc-layer-desc">{layer.desc}</span>
      <span className="nrc-layer-tech">
        {layer.tech.map((item) => (
          <span className="nrc-chip" key={`${index}-${item}`}>
            {item}
          </span>
        ))}
      </span>
    </div>
  );
}

export default function Technology() {
  const [headRef, headIn] = useReveal<HTMLDivElement>();

  return (
    <section className="nrc-section" id="technology">
      <div className="nrc-wrap">
        <div className={`nrc-rv ${headIn ? "is-in" : ""}`} ref={headRef}>
          <h2 className="nrc-h2">Built for technical intelligence.</h2>
          <p className="nrc-lede">
            Seven layers, one job each. A request enters at the top and leaves traceable to
            the document it came from.
          </p>
        </div>

        <div className="nrc-arch">
          {LAYERS.map((layer, index) => (
            <Layer index={index} key={layer.n} layer={layer} />
          ))}
        </div>
      </div>
    </section>
  );
}

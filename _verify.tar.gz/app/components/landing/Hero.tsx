"use client";

import dynamic from "next/dynamic";
import { useEffect, useState, type ReactNode } from "react";
import { ArrowRight, CornerDownLeft } from "lucide-react";
import { CATALOG_COUNTS } from "./catalog.data";
import { scrollToId } from "./nav";

/* The drawing is still split out of the first payload and mounted after the
   headline has painted — it is the largest single piece of markup on the page —
   but it is now plain SVG rather than a WebGL scene. */
const HeroDrawing = dynamic(() => import("./HeroDrawing"), { ssr: false });

type HeroProps = {
  /** The application's live search form, rendered by the page that owns its state. */
  searchSlot: ReactNode;
  onExploreTechnology: () => void;
};

export default function Hero({ searchSlot, onExploreTechnology }: HeroProps) {
  const [ready, setReady] = useState(false);
  const [sceneMounted, setSceneMounted] = useState(false);

  useEffect(() => {
    const raf = requestAnimationFrame(() => setReady(true));
    // Deferred so it never competes with the first paint of the headline and
    // the search field.
    const idle = window.setTimeout(() => setSceneMounted(true), 260);
    return () => {
      cancelAnimationFrame(raf);
      window.clearTimeout(idle);
    };
  }, []);

  /* Staggered entrance: every hero element shares one reveal transition and
     differs only in its delay, so the sequence reads as one composed move. */
  const stage = (delay: number, base = "") => ({
    className: `${base} nrc-rv${ready ? " is-in" : ""}`.trim(),
    style: { "--rv-delay": `${delay}ms` } as React.CSSProperties,
  });

  return (
    <section className="nrc-hero" id="top">
      <div className="nrc-hero-canvas" aria-hidden="true">
        {sceneMounted ? <HeroDrawing /> : null}
      </div>
      <div className="nrc-hero-scrim" aria-hidden="true" />

      <div className="nrc-hero-inner">
        <p {...stage(120, "nrc-hero-eyebrow")}>
          <span className="nrc-pulse" aria-hidden="true" />
          For construction projects in the UAE
        </p>

        <h1 {...stage(220)}>
          Construction Chemistry,
          <span className="nrc-hero-line2">Intelligently Engineered.</span>
        </h1>

        <p {...stage(340, "nrc-hero-sub")}>
          AI-powered construction chemical recommendations for smarter, faster and more
          reliable project decisions.
        </p>

        <div {...stage(440, "nrc-hero-actions")}>
          <button
            className="nrc-btn nrc-btn--primary"
            onClick={() => scrollToId("recommendation")}
            type="button"
          >
            Explore AI Recommendations
            <ArrowRight size={16} strokeWidth={2.2} aria-hidden="true" />
          </button>
          <button className="nrc-btn nrc-btn--ghost" onClick={onExploreTechnology} type="button">
            Explore the Technology
            <ArrowRight size={16} strokeWidth={2.2} aria-hidden="true" />
          </button>
        </div>

        <div {...stage(560, "nrc-hero-search")}>
          <p className="nrc-hero-search-hint">
            <CornerDownLeft size={13} strokeWidth={2.2} aria-hidden="true" />
            Start with a project condition
          </p>
          {searchSlot}
        </div>
      </div>

      <div {...stage(700, "nrc-hero-readout")}>
        <div>
          <span className="nrc-readout-k">Product profiles</span>
          <span className="nrc-readout-v">
            {CATALOG_COUNTS.profiles.toLocaleString("en-US")}
          </span>
        </div>
        <div>
          <span className="nrc-readout-k">Market catalog</span>
          <span className="nrc-readout-v">{CATALOG_COUNTS.marketProducts} products</span>
        </div>
        <div>
          <span className="nrc-readout-k">Product categories</span>
          <span className="nrc-readout-v">{CATALOG_COUNTS.marketCategories}</span>
        </div>
        <div>
          <span className="nrc-readout-k">Retrieval</span>
          <span className="nrc-readout-v">
            <em>Live</em>
          </span>
        </div>
      </div>
    </section>
  );
}

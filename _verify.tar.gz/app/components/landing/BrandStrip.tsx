"use client";

import BrandScroller from "../BrandScroller";
import { CATALOG_COUNTS } from "./catalog.data";
import { useReveal } from "../../lib/hooks";

/**
 * Reuses the existing brand marquee (fed by /brands/manifest.json) as the
 * "whose catalogs are in here" band between the problem and the engine.
 * Restyled for the dark surface via .nrc-brands, not by editing the component.
 */
export default function BrandStrip() {
  const [revealRef, revealIn] = useReveal<HTMLDivElement>({ threshold: 0.3 });

  return (
    <section className="nrc-brands" aria-label="Manufacturers represented in the catalog">
      <div className={`nrc-wrap nrc-rv ${revealIn ? "is-in" : ""}`} ref={revealRef}>
        <p className="nrc-label nrc-label--plain nrc-brands-label">
          {CATALOG_COUNTS.brandLogos} manufacturer catalogs in the index
        </p>
      </div>
      <BrandScroller visible />
    </section>
  );
}

"use client";

import Image from "next/image";
import { useEffect, useState } from "react";
import { ArrowRight, Menu, X } from "lucide-react";
import { NAV_LINKS, scrollToId } from "./nav";

type NavbarProps = {
  onTryAi: () => void;
};

/**
 * Transparent over the hero, densifying into a blurred bar once the user
 * scrolls. The links are in-page anchors: the application is a single route,
 * so inventing /product or /technology pages would create dead ends.
 */
export default function Navbar({ onTryAi }: NavbarProps) {
  const [stuck, setStuck] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    function onScroll() {
      setStuck(window.scrollY > 24);
    }
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close the mobile sheet when the viewport grows past the breakpoint,
  // otherwise it stays mounted and swallows clicks on desktop.
  useEffect(() => {
    const query = window.matchMedia("(min-width: 901px)");
    const onChange = () => setOpen(false);
    query.addEventListener("change", onChange);
    return () => query.removeEventListener("change", onChange);
  }, []);

  function go(id: string) {
    setOpen(false);
    scrollToId(id);
  }

  return (
    <header className={`nrc-nav${stuck || open ? " is-stuck" : ""}`}>
      <div className="nrc-nav-inner">
        <a
          className="nrc-brand"
          href="#top"
          onClick={(event) => {
            event.preventDefault();
            go("top");
          }}
        >
          <span className="nrc-brand-mark" aria-hidden="true">
            <Image src="/icons/brand-mark.png" alt="" width={22} height={22} priority />
          </span>
          NiRaConChem AI
        </a>

        <nav className="nrc-nav-links" aria-label="Primary">
          {NAV_LINKS.map((link) => (
            <a
              key={link.id}
              href={`#${link.id}`}
              onClick={(event) => {
                event.preventDefault();
                go(link.id);
              }}
            >
              {link.label}
            </a>
          ))}
        </nav>

        <button className="nrc-btn nrc-btn--primary nrc-btn--sm nrc-nav-cta" onClick={onTryAi} type="button">
          Try AI
          <ArrowRight size={15} strokeWidth={2.2} aria-hidden="true" />
        </button>

        <button
          aria-controls="nrc-nav-sheet"
          aria-expanded={open}
          aria-label={open ? "Close menu" : "Open menu"}
          className="nrc-nav-burger"
          onClick={() => setOpen((value) => !value)}
          type="button"
        >
          {open ? <X size={18} strokeWidth={2.2} /> : <Menu size={18} strokeWidth={2.2} />}
        </button>
      </div>

      <div className={`nrc-nav-sheet${open ? " is-open" : ""}`} id="nrc-nav-sheet">
        {NAV_LINKS.map((link) => (
          <a
            key={link.id}
            href={`#${link.id}`}
            onClick={(event) => {
              event.preventDefault();
              go(link.id);
            }}
          >
            {link.label}
          </a>
        ))}
        <button
          className="nrc-btn nrc-btn--primary"
          onClick={() => {
            setOpen(false);
            onTryAi();
          }}
          type="button"
        >
          Try AI
          <ArrowRight size={16} strokeWidth={2.2} aria-hidden="true" />
        </button>
      </div>
    </header>
  );
}
